package ds;

/*
 * @author Sachal Magon (smagon)
 *
 * This file is the Model component of the MVC, and it models the business
 * logic for the web application.  In this case, the business logic involves
 * counting the number of choice the user choose.
 */

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class ClassClickerModel {
    /**
     * Arguments.
     *
     * @param searchTag The tag of the choice.
     * @param picSize The string "mobile" or "desktop" indicating the size of
     * photo requested.
     */
    //to maintain the count of the choice made
    int a=0,b=0,c=0,d=0;


    public String doCurrentChoice(String searchTag, String picSize)
            throws UnsupportedEncodingException  {
        /*
         * There is no reason that UTF-8 would be unsupported.  It is the
         * standard encoding today.  So if it is not supported, we have
         * big problems, so don't catch the exception.
         */
        searchTag = URLEncoder.encode(searchTag, "UTF-8");

        // check whoch option did it choose to increment the count of the counter of each choice
        if(searchTag.equalsIgnoreCase("A")) {
            a++;
        }
        if(searchTag.equalsIgnoreCase("B")) {
            b++;
        }
        if(searchTag.equalsIgnoreCase("C")) {
            c++;
        }
        if(searchTag.equalsIgnoreCase("D")) {
            d++;
        }
         return searchTag;
    }
    // called in the servlet to clear the values of A, B, C and D after the getResults is called
    public void clear()
    {
        //declaring the count to be 0 for each counter
        a=0;b=0;c=0;d=0;
    }
}
