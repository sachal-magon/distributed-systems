package ds;
/*
 * @author Sachal Magon(smagon)
 *
 * The servlet is acting as the controller.
 * There are three views - prompt.jsp and result.jsp and results1.jsp
 * It decides between the three by determining if there is a search parameter or
 * not to choose prompt.jsp or results.jsp.
 * If there is no parameter, then it uses the prompt.jsp view, as a
 * starting place. If there is a search parameter, but to /getResults then it searches for a
 * picture and uses the result.jsp/results1.jsp view.
 * The model is provided by ClassClickerModel.
 */

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * The following WebServlet annotation gives instructions to the web container.
 * It states that when the user browses to the URL path /get
 * then the servlet with the name InterestingPictureServlet should be used.
 */
@WebServlet(name = "ClassClickerServlet",
        urlPatterns = {"/getClassClicker", "/getResults"})

public class ClassClickerServlet extends HttpServlet {

    ClassClickerModel ipm = null;  // The "business model" for this app

    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {
        ipm = new ClassClickerModel();
    }

    // This servlet will reply to HTTP GET requests via this doGet method
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        // get the choice parameter if it exists
        String search = request.getParameter("choice");

        // determine what type of device our user is
        String ua = request.getHeader("User-Agent");

        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }

        String nextView;

        // take the count of a, b, c and d choice from the model to the servlet
        int a = ipm.a, b = ipm.b, c = ipm.c, d = ipm.d;
        request.setAttribute("A_num",a);
        request.setAttribute("B_num",b);
        request.setAttribute("C_num",c);
        request.setAttribute("D_num",d);

        //to clear if the getResults is been called
        ipm.clear();
        String url = request.getRequestURL().toString();

        //check if the url contains /getResults
        if (url.contains("/getResults")) {
            // use model to do the search and choose the result view
            nextView = "results1.jsp";
        } else {
            // no choice parameter so choose the prompt view
            nextView = "prompt.jsp";
        }
        // Transfer control over the the correct "view"
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
    // This servlet will reply to HTTP POST requests via this doPost method
    protected void doPost(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        String url = request.getRequestURL().toString();
        String search = request.getParameter("choice");

        // determine what type of device our user is
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        String ua = request.getHeader("User-Agent");
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
        request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
    } else {
        mobile = false;
        request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
    }

        String picSize = (mobile) ? "mobile" : "desktop";
        String currentChoice = ipm.doCurrentChoice(search.toUpperCase(), picSize);
        request.setAttribute("currentChoice",currentChoice);

        String nextView;
        // Pass the user search string (pictureTag) also to the view.
        nextView = "result.jsp";
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
}
