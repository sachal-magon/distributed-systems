package ds;
/*
 * @author Sachal Magon
 *
 * This file is the Model component of the MVC, and it models the business
 * logic for the web application.  In this case, the business logic involves
 * making a request to cia.gov website and then screen scraping the HTML that is
 * returned in order to fabricate an image URL(flag image) and description.
 */

import org.jsoup.Jsoup;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class FlagModel {
    /**
     * Arguments.
     *
     * @param searchTag The tag of the country to be searched for.
     * @param picSize The string "mobile" or "desktop" indicating the size of
     * photo requested.
     */
    public String doFlagSearch(String searchTag, String picSize)
            throws UnsupportedEncodingException  {
        /*
         * There is no reason that UTF-8 would be unsupported.  It is the
         * standard encoding today.  So if it is not supported, we have
         * big problems, so don't catch the exception.
         */
        searchTag = URLEncoder.encode(searchTag, "UTF-8");

        String response = "";
        // Create a URL for the page to be screen scraped
        String ciaURL =
                "https://www.cia.gov/library/publications/resources/the-world-factbook/attachments/flags/"
                        + searchTag
                        +"-flag.gif";

        // Fetch the page
        response = fetch(ciaURL);

        /*
         * Search the page to find the flag URL
         *
         * Screen scraping is an art that requires creatively looking at the
         * HTML that is returned and figuring out how to cut out the data that
         * is important to you.
         *
         * These particular searches were crafted by carefully looking at
         * the HTML that cia.gov returned, and finding (by experimentation) the
         * generalizable steps that will reliably get a flag URL.
         */
        return ciaURL;
    }


    public String doDescriptionSearch(String searchTag, String picSize)
            throws UnsupportedEncodingException  {
        /*
         * There is no reason that UTF-8 would be unsupported.  It is the
         * standard encoding today.  So if it is not supported, we have
         * big problems, so don't catch the exception.
         */
        searchTag = URLEncoder.encode(searchTag, "UTF-8");

        String response = "";
        // Create a URL for the page to be screen scraped
        String descriptionURL =
                "https://www.cia.gov/library/publications/resources/the-world-factbook/geos/"
                        + searchTag
                        +".html";
        // Fetch the page
        response = fetch(descriptionURL);

        // used Jsoup to parse the HTML from the cia.gov website
        Document doc = Jsoup.parse(response);
        Element content = doc.getElementsByClass("photogallery_captiontext").first();
        String linkClass = content.text();
        Element countryname = doc.getElementsByClass("region_name1 countryName").first();
        String countryName = countryname.text();
        String returnmodel = countryName +"____"+linkClass;

        //return the country name and the description with the "____" string between the two strings
        return returnmodel;
    }

    private String fetch(String urlString) {
        String response = "";

        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
        } catch (IOException e) {
            System.out.println("");
        }
        return response;
    }
}

