package ds;

/*
 * @author Sachal Magon
 * The welcome-file in the deployment descriptor (web.xml) points
 * to this servlet.  So it is also the starting place for the web
 * application.
 *
 * The servlet is acting as the controller as well as the model for this task.
 * There are two views - index.jsp and result.jsp.
 * It decides between the two by determining if there is text or
 * not. If there is no parameter, then it uses the index.jsp view, as a
 * starting place. If there is text present, then it calculates the hash
 *  for the text and uses the result.jsp view.
 */

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

// webservlet matches the url patterns from the web.xml file to direct the program to the servlet
@WebServlet(name = "ComputeHashes",
        urlPatterns = {"/computeHash"})
public class ComputeHashes extends HttpServlet{
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        // get the text and hash function if it exists
        String textData = request.getParameter("textData");
        String hash = request.getParameter("hash");
        // computing the hash value by using the appropriate function
        try {
            // making an instance of Message digest by using the getInstance function
            if(textData!=null) {
                MessageDigest md = MessageDigest.getInstance(hash);
                byte[] hashInBytes = md.digest(textData.getBytes(StandardCharsets.UTF_8));
                // convert hash in bytes to the string of text(64 or hex)
                String hashtext64 = javax.xml.bind.DatatypeConverter.printBase64Binary(hashInBytes);
                String hashtexthex = javax.xml.bind.DatatypeConverter.printHexBinary(hashInBytes);

                //sets the request attribute to the desired hashes
                request.setAttribute("hash64", hashtext64);
                request.setAttribute("hashhex", hashtexthex);
            }
        }
        // For specifying wrong message digest algorithms
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        String nextView;
        /*
         * Check if the text is present.
         * If not, then give the user instructions and open the index view.
         * If there is a text parameter, then do hashing and return the result.
         */

        if (textData != null) {
            // Pass the user search string (pictureTag) also to the view.
            nextView = "result.jsp";
        } else {
            // no search parameter so choose the index view
            nextView = "index.jsp";
        }
        // Transfer control over the the correct "view"
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
}
